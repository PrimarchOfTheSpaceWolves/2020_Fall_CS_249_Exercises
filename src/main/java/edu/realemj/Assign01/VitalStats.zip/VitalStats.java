package edu.realemj.Assign01;

public class VitalStats {
    public static void main(String [] args) {

    }
}
