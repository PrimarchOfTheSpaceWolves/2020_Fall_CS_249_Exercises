package edu.realemj.Assign01;

public class RPGHelper {
    public static void main(String [] args) {

    }
}
